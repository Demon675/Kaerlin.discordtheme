How to Install Vencord and Use Custom CSS Themes
What is Vencord?
Vencord is a popular client modification for Discord that allows you to customize your Discord client, including adding custom CSS themes.

Step 1: Download and Install Vencord
Go to the official Vencord website or GitHub page
Visit the official source to download the latest version of Vencord safely.

Official GitHub: https://github.com/Vencord/Vencord

Or the official website linked from GitHub

Download the Installer
Find the installer for your operating system (Windows, macOS, or Linux) and download it.

Run the Installer

Close Discord completely (make sure it’s not running in the system tray).

Run the Vencord installer. It will patch your Discord client to enable Vencord features.

Start Discord
Launch Discord as normal. You should see a Vencord logo or menu indicating that Vencord is active.

Step 2: Add Custom CSS Themes in Vencord
Open Vencord Settings
Inside Discord, go to User Settings (the gear icon at the bottom left), then find the Vencord tab.

Find the Theme or Appearance Section
In Vencord settings, look for options related to Themes or Custom CSS.

Add Custom CSS

There should be an option to add custom CSS code or upload CSS files.

Paste your custom CSS code directly or load a .css file if supported.

Enable the Theme
After adding your CSS, make sure to enable or apply the theme in the Vencord settings.

Restart Discord if Needed
Some CSS changes might require restarting Discord to take effect fully.

Tips for Custom CSS in Vencord
Backup your CSS: Save your custom CSS code somewhere safe in case you need to reinstall or reset.

Test changes gradually: Add CSS in small parts to avoid breaking the Discord UI.

Look for community themes: You can find pre-made Vencord CSS themes on Discord theme repositories or GitHub.

Update Vencord regularly: Updates may fix bugs and improve compatibility with Discord updates.

